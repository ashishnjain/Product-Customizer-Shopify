import React from 'react';

const FrontendPreviewModal = () => {
  return (
    <div>
      <h2>Preview Modal</h2>
    </div>
  );
};

export default FrontendPreviewModal;
